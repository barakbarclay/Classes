//Creating and reading binary files
 
#include <iostream>                                 //Line 1
#include <fstream>                                  //Line 2
  
using namespace std;                                //Line 3
 
struct studentType                                  //Line 4
{                                                   //Line 5
    char firstName[15];                             //Line 6
    char lastName[15];                              //Line 7
    int ID;                                         //Line 8
};                                                  //Line 9

int main()                                          //Line 10
{                                                   //Line 11
      //create and initialize an array of students� IDs
    int studentIDs[5] = {111111, 222222, 333333,
                         444444, 555555};           //Line 12

      //declare and initialize the struct newStudent
    studentType newStudent = {"John", "Wilson",
                              777777};              //Line 13

    ofstream outFile;                               //Line 14

      //open the output file as a binary file
    outFile.open("ids.dat", ios::binary);           //Line 15

      //write the array in the binary format
    outFile.write(reinterpret_cast<const char *> (studentIDs),
                  sizeof(studentIDs));              //Line 16 

      //write the newStudent data in the binary format
    outFile.write(reinterpret_cast<const char *> (&newStudent),
                  sizeof(newStudent));              //Line 17 

    outFile.close();  //close the file              //Line 18

    ifstream inFile;                                //Line 19
    int arrayID[5];                                 //Line 20
    studentType student;                            //Line 21
    
      //open the input file
    inFile.open("ids.dat");                         //Line 22

    if (!inFile)                                    //Line 23
    {                                               //Line 24
        cout << "The input file does not exist. "
             << "The program terminates!!" << endl; //Line 25
        return 1;                                   //Line 26
    }                                               //Line 27

      //input the data into the array arrayID
    inFile.read(reinterpret_cast<char *> (arrayID),
                sizeof(arrayID));                   //Line 28
      //output the data of the array arrayID
    for (int i = 0; i < 5; i++)                     //Line 29
        cout << arrayID[i] << " ";                  //Line 30
    cout << endl;                                   //Line 31

      //read the student's data
    inFile.read(reinterpret_cast<char *> (&student),  
                sizeof(student));                   //Line 32

      //output studentData
    cout << student.ID << " " << student.firstName 
         << " " << student.lastName << endl;        //Line 33

    inFile.close();     //close the file            //Line 34

    return 0;                                       //Line 35
}                                                   //Line 36
