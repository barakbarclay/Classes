  
//STL Functions search, sort, and binary_search

#include <iostream>                                   //Line 1
#include <algorithm>                                  //Line 2
#include <iterator>                                   //Line 3
#include <vector>                                     //Line 4

using namespace std;                                  //Line 5
   
int main()                                            //Line 6
{                                                     //Line 7
    int intList[15] = {12, 34, 56, 34, 34, 
                       78, 38, 43, 12, 25,
                       34, 56, 62, 5, 49};            //Line 8

    vector<int> vecList(intList, intList + 15);       //Line 9
    int list[2] = {34, 56};                           //Line 10

    vector<int>::iterator location;                   //Line 11

    ostream_iterator<int> screenOut(cout, " ");       //Line 12

    cout << "Line 13: vecList: ";                     //Line 13
    copy(vecList.begin(), vecList.end(), screenOut);  //Line 14
    cout << endl;                                     //Line 15

    cout << "Line 16: list: ";                        //Line 16
    copy(list, list + 2, screenOut);                  //Line 17
    cout << endl;                                     //Line 18

        //search
    location = search(vecList.begin(), vecList.end(),
                      list, list + 2);                //Line 19

    if (location != vecList.end())                    //Line 20
        cout << "Line 21: list found in vecList. "
             << "The first occurrence of \n       "
             << "  list in vecList is at position: "
             << (location - vecList.begin())
             << endl;                                 //Line 21
    else                                              //Line 22
        cout << "Line 23: list is not in vecList."
             << endl;                                 //Line 23

        //sort
    sort(vecList.begin(), vecList.end());             //Line 24

    cout << "Line 25: vecList after sorting:\n"
         << "         ";                              //Line 25
    copy(vecList.begin(), vecList.end(), screenOut);  //Line 26
    cout << endl;                                     //Line 27

        //binary_search
    bool found;                                       //Line 28

    found = binary_search(vecList.begin(), 
                          vecList.end(), 78);         //Line 29

    if (found)                                        //Line 30
        cout << "Line 31: 43 found in vecList "
             << endl;                                 //Line 31
    else                                              //Line 32
        cout << "Line 33: 43 not in vecList" << endl; //Line 33

    return 0;                                         //Line 34
}                                                     //Line 35
