//Creating and reading a random access file.

#include <iostream>                                 //Line 1
#include <fstream>                                  //Line 2
#include <iomanip>                                  //Line 3
 
using namespace std;                                //Line 4

struct studentType                                  //Line 5
{                                                   //Line 6
    char firstName[15];                             //Line 7
    char lastName[15];                              //Line 8
    int ID;                                         //Line 9
    double GPA;                                     //Line 10
};                                                  //Line 11

void printStudentData(const studentType& student);  //Line 12

int main()                                          //Line 13
{                                                   //Line 14
    studentType st;                                 //Line 15
    ifstream inFile;                                //Line 16
    ofstream outFile;                               //Line 17

    long studentSize = sizeof(st);                  //Line 18

      //open the input file, which is a text file
    inFile.open("studentData.txt");                 //Line 19

    if (!inFile)                                    //Line 20
    {                                               //Line 21
        cout << "The input file does not exist. "
             << "The program terminates!!" << endl; //Line 22
       return 1;                                    //Line 23
    }                                               //Line 24

      //open a binary output file
    outFile.open("student.dat", ios::binary);       //Line 25

    inFile >> st.ID >> st.firstName
           >> st.lastName >> st.GPA;                //Line 26

    while (inFile)                                  //Line 27
    {                                               //Line 28
        outFile.seekp((st.ID - 1) * studentSize, 
                       ios::beg);                   //Line 29
        outFile.write(reinterpret_cast<const char *> (&st),
                      sizeof(st));                  //Line 30
        inFile >> st.ID >> st.firstName
               >> st.lastName >> st.GPA;            //Line 31
    }                                               //Line 32

    inFile.close();                                 //Line 33
    inFile.clear();                                 //Line 34
    outFile.close();                                //Line 35

    cout << left << setw(3) << "ID"
         << setw(16) << "First Name"
         << setw(16) << "Last Name"
         << setw(12) << "Current GPA" << endl;      //Line 36
    cout << fixed << showpoint << setprecision(2);  //Line 37

      //open the input file, which is a binary file
    inFile.open("student.dat", ios::binary);        //Line 38

    if (!inFile)                                    //Line 39
    {                                               //Line 40
       cout << "The input file does not exist. "
            << "The program terminates!!" << endl;  //Line 41
       return 1;                                    //Line 42
    }                                               //Line 43

      //read the data at location 0 in the file
    inFile.read(reinterpret_cast<char *> (&st),
                sizeof(st));                        //Line 44

    while (inFile)                                  //Line 45
    {                                               //Line 46
        if (st.ID != 0)                             //Line 47
            printStudentData(st);                   //Line 48

          //read the data at the current reading position
        inFile.read(reinterpret_cast<char *> (&st),
                    sizeof(st));                    //Line 49
    }                                               //Line 50

    return 0;                                       //Line 51
}                                                   //Line 52

void printStudentData(const studentType& student)   //Line 53
{
    cout << left << setw(3) << student.ID 
         << setw(16) << student.firstName 
         << setw(16) << student.lastName  
         << right << setw(10) << student.GPA
         << endl;                                   //Line 54
}                                                   //Line 55
