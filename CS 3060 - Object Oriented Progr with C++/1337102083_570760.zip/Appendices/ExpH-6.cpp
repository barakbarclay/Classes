   
//deque Example
#include <iostream>                               //Line 1
#include <deque>                                  //Line 2
#include <algorithm>                              //Line 3
#include <iterator>                               //Line 4
  
using namespace std;                              //Line 5
 
int main()                                        //Line 6
{                                                 //Line 7
    deque<int> intDeq;                            //Line 8
    ostream_iterator<int> screen(cout, " ");      //Line 9
 
    intDeq.push_back(13);                         //Line 10
    intDeq.push_back(75);                         //Line 11
    intDeq.push_back(28);                         //Line 12
    intDeq.push_back(35);                         //Line 13

    cout << "Line 14: intDeq: ";                  //Line 14
    copy(intDeq.begin(), intDeq.end(), screen);   //Line 15
    cout << endl;                                 //Line 16

    intDeq.push_front(0);                         //Line 17
    intDeq.push_back(100);                        //Line 18

    cout << "Line 19: After adding two more "
         << "elements, one at the front " << endl
         << "         and one at the back, " 
         <<"intDeq: ";                            //Line 19
    copy(intDeq.begin(), intDeq.end(), screen);   //Line 20
    cout << endl;                                 //Line 21

    intDeq.pop_front();                           //Line 22
    intDeq.pop_front();                           //Line 23

    cout << "Line 24: After removing the first "
         << "two elements, " << endl
         << "         intDeq: ";                  //Line 24
    copy(intDeq.begin(), intDeq.end(), screen);   //Line 25
    cout << endl;                                 //Line 26

    intDeq.pop_back();                            //Line 27
    intDeq.pop_back();                            //Line 28

    cout << "Line 29: After removing the last "
         << "two elements, " << endl
         << "         intDeq: ";                  //Line 29
    copy(intDeq.begin(), intDeq.end(), screen);   //Line 30
    cout << endl;                                 //Line 31

    return 0;                                     //Line 32
}                                                 //Line 33
