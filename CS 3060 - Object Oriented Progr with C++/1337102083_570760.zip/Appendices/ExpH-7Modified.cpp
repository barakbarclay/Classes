  
//List Container Example ExpH-7Modified

#include <iostream>                                   //Line 1
#include <list>                                       //Line 2
#include <iterator>                                   //Line 3
#include <algorithm>                                  //Line 4         
 
using namespace std;                                  //Line 5
  
int main()                                            //Line 6
{                                                     //Line 7
    list<int> intList1, intList2, intList3;           //Line 8

    intList1.push_back(23);                           //Line 9
    intList1.push_back(58);                           //Line 10
    intList1.push_back(58);                           //Line 11
    intList1.push_back(58);                           //Line 12
    intList1.push_back(36);                           //Line 13
    intList1.push_back(15);                           //Line 14
    intList1.push_back(93);                           //Line 15
    intList1.push_back(98);                           //Line 16
    intList1.push_back(58);                           //Line 17

    cout << "Line 18: intList1: ";                    //Line 18
    for (auto p : intList1)                           //Line 19
        cout << p << " ";                             //Line 20 ***
    cout << endl;                                     //Line 21

    intList2 = intList1;                              //Line 22

    cout << "Line 23: intList2: ";                    //Line 23
    for (auto p : intList2)                           //Line 24
        cout << p << " ";                             //Line 25 ***
    cout << endl;                                     //Line 26

    intList1.unique();                                //Line 27

    cout << "Line 28: After removing the consecutive "
         << "duplicates," << endl
         << "         intList1: ";                    //Line 28
    for (auto p : intList1)                           //Line 29
        cout << p << " ";                             //Line 30
    cout << endl;                                     //Line 31

    intList2.sort();                                  //Line 32

    cout << "Line 33: After sorting, intList2: ";     //Line 33
    for (auto p : intList2)                           //Line 34
        cout << p << " ";                             //Line 35 ***
    cout << endl;                                     //Line 36

    intList3.push_back(13);                           //Line 37
    intList3.push_back(25);                           //Line 38
    intList3.push_back(23);                           //Line 39
    intList3.push_back(198);                          //Line 40
    intList3.push_back(136);                          //Line 41
 
    cout << "Line 42: intList3: ";                    //Line 42
    for (auto p : intList3)                           //Line 43
        cout << p << " ";                             //Line 44 ***
    cout << endl;                                     //Line 45

    intList3.sort();                                  //Line 46

    cout << "Line 47: After sorting, intList3: ";     //Line 47
    for (auto p : intList3)                           //Line 48
        cout << p << " ";                             //Line 49 ***
    cout << endl;                                     //Line 50

    intList2.merge(intList3);                         //Line 51

    cout << "Line 52: After merging intList2 and "
         << "intList3, intList2: " << endl
         << "         ";                              //Line 52 
    for (auto p : intList2)                           //Line 53
        cout << p << " ";                             //Line 54 ***
    cout << endl;                                     //Line 55
 
    return 0;                                         //Line 56
}                                                     //Line 57
