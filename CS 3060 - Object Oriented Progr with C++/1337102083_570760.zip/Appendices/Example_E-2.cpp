//Creating and reading a binary file consisting of 
//bank customers' data
 
#include <iostream>                                 //Line 1
#include <fstream>                                  //Line 2
#include <iomanip>                                  //Line 3
 
using namespace std;                                //Line 4

struct customerType                                 //Line 5
{                                                   //Line 6
    char firstName[15];                             //Line 7
    char lastName[15];                              //Line 8
    int ID;                                         //Line 9
    double balance;                                 //Line 10
};                                                  //Line 11

int main()                                          //Line 12
{                                                   //Line 13
    customerType cust;                              //Line 14
    ifstream inFile;                                //Line 15
    ofstream outFile;                               //Line 16

    inFile.open("customerData.txt");                //Line 17

    if (!inFile)                                    //Line 18
    {                                               //Line 19
        cout << "The input file does not exist. "
             << "The program terminates!!" << endl; //Line 20
        return 1;                                   //Line 21
    }                                               //Line 22

    outFile.open("customer.dat", ios::binary);      //Line 23

    inFile >> cust.ID >> cust.firstName >> cust.lastName
           >> cust.balance;                         //Line 24

    while (inFile)                                  //Line 25
    {                                               //Line 26
         outFile.write(reinterpret_cast<const char *> (&cust),
                       sizeof(cust));               //Line 27
         inFile >> cust.ID >> cust.firstName
                >> cust.lastName >> cust.balance;   //Line 28
    }                                               //Line 29

    inFile.close();                                 //Line 30
    inFile.clear();                                 //Line 31
    outFile.close();                                //Line 32

    inFile.open("customer.dat", ios::binary);       //Line 33

    if (!inFile)                                    //Line 34
    {                                               //Line 35
        cout << "The input file does not exist. "
             << "The program terminates!!" << endl; //Line 36
        return 1;                                   //Line 37
    }                                               //Line 38

    cout << left << setw(8) << "ID"
         << setw(16) << "First Name"
         << setw(16) << "Last Name"
         << setw(10) << " Balance" << endl;         //Line 39
    cout << fixed << showpoint << setprecision(2);  //Line 40

      //read and output the data from the binary
      //file customer.dat
    inFile.read(reinterpret_cast<char *> (&cust),
                sizeof(cust));                      //Line 41
    while (inFile)                                  //Line 42
    {                                               //Line 43
         cout << left << setw(8) << cust.ID 
              << setw(16) << cust.firstName 
              << setw(16) << cust.lastName  
              << right << setw(10) << cust.balance
              << endl;                              //Line 44
        inFile.read(reinterpret_cast<char *> (&cust),
                    sizeof(cust));                  //Line 45
    }                                               //Line 46

    inFile.close();     //close the file            //Line 47

    return 0;                                       //Line 48
}                                                   //Line 49
