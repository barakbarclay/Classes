  
//STL Functions remove and replace
 
#include <iostream>                                   //Line 1
#include <cctype>                                     //Line 2
#include <algorithm>                                  //Line 3
#include <iterator>                                   //Line 4
#include <vector>                                     //Line 5

using namespace std;                                  //Line 6
 
int main()                                            //Line 7
{                                                     //Line 8
    char cList[10] = {'A', 'a', 'A', 'B', 'A', 
                      'c', 'D', 'e', 'F', 'A'};       //Line 9

    vector<char> charList1(cList, cList + 10);        //Line 10
    vector<char> charList2(cList, cList + 10);        //Line 11

    vector<char>::iterator lastElem;                  //Line 12

    ostream_iterator<char> screen(cout, " ");         //Line 13

    cout << "Line 14: Character list 1: ";            //Line 14
    copy(charList1.begin(), charList1.end(), screen); //Line 15
    cout << endl;                                     //Line 16
  
        //remove 
    lastElem = remove(charList1.begin(), 
                      charList1.end(), 'A');          //Line 17

    cout << "Line 18: Character list 1 after " 
         << "removing A: ";                           //Line 18
    copy(charList1.begin(), lastElem, screen);        //Line 19
    cout << endl;                                     //Line 20

    cout << "Line 21: Character list 2: ";            //Line 21
    copy(charList2.begin(), charList2.end(), screen); //Line 22
    cout << endl;                                     //Line 23

        //replace 
    replace(charList2.begin(), charList2.end(), 
                               'A', 'Z');             //Line 24

    cout << "Line 25: Character list 2 after "
         << "replacing A with Z: " << endl;           //Line 25
    copy(charList2.begin(), charList2.end(), screen); //Line 26
    cout << endl;                                     //Line 27

    return 0;                                         //Line 28
}                                                     //Line 29
