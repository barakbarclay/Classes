// This program shows the effect of escape sequences.
  
#include <iostream>

using namespace std; 
 
int main() 
{
    cout << "The newline escape sequence is \\n" << endl;
    cout << "The tab character is represented as \'\\t\'" << endl;
    cout << "The tab character is represented as '\\t'" << endl;
    cout << "The string \"Sunny\" contains five characters." << endl;
    
    return 0;
}
