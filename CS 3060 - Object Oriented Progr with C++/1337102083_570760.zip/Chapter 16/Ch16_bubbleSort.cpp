 
//Bubble sort
 
#include <iostream>                                 //Line 1

using namespace std;                                //Line 2
 
void bubbleSort(int list[],  int length);           //Line 3

int main()                                          //Line 4
{                                                   //Line 5
    int list[] = {20, 36, 24, 65, 78, 45, 58,
                  90, 2, 15};                       //Line 6

    bubbleSort(list, 10);                           //Line 7

    cout << "After sorting, the list "
         << "elements are: " << endl;               //Line 8

    for (int i = 0; i < 10; i++)                    //Line 9
        cout << list[i] << " ";                     //Line 10

    cout << endl;                                   //Line 11

    return 0;                                       //Line 12
}                                                   //Line 13

void bubbleSort(int list[], int length)
{
    int temp;

    for (int iteration = 1; iteration < length; iteration++)
    {
        for (int index = 0; index < length - iteration; index++)
            if (list[index] > list[index + 1]) 
            {
                temp = list[index];
                list[index] = list[index + 1];
                list[index + 1] = temp;
            }
    }
}
