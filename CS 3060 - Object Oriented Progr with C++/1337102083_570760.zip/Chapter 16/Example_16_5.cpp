
#include <iostream>                         //Line 1
#include <vector>                           //Line 2

using namespace std;                        //Line 3

int main()                                  //Line 4
{                                           //Line 5
    vector<int> intList;                    //Line 6
    unsigned int i;                         //Line 7

    intList.push_back(24);                  //Line 8
    intList.push_back(39);                  //Line 9
    intList.push_back(90);                  //Line 10
    intList.push_back(66);                  //Line 11

    cout << "Line 12: List Elements: ";     //Line 12

    for (i = 0; i < intList.size(); i++)    //Line 13
        cout << intList[i] << " ";          //Line 14
    cout << endl;                           //Line 15

    for (i = 0; i < intList.size(); i++)    //Line 16
        intList[i] = intList[i] * 2;        //Line 17

    cout << "Line 18: List Elements: ";     //Line 18

    for (i = 0; i < intList.size(); i++)    //Line 19
        cout << intList[i] << " ";          //Line 20

    cout << endl;                           //Line 21

    return 0;                               //Line 22
}                                           //Line 23

